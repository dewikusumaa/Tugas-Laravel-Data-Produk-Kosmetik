<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});




//kosmetik
Route::get('/kosmetik/index', 'KosmetikController@index');
Route::get('/kosmetik/create', 'KosmetikController@create');
Route::get('/kosmetik/{kosmetik}', 'KosmetikController@show');
Route::post('/kosmetik', 'KosmetikController@store');
Route::delete('/kosmetik/{kosmetik}', 'KosmetikController@destroy');
Route::get('/kosmetik/{kosmetik}/edit', 'KosmetikController@edit');
Route::patch('/kosmetik/{kosmetik}', 'KosmetikController@update');