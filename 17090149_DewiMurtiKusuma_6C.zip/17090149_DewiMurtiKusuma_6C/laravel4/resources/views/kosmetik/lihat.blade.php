@extends('layout/main')
@section('content')

<div class="container">
    <div class="row">
        <div class="col-4">
            <h1 class="mt-3">Detail Product</h1>

            <div class="card">
                <div class="card-body">
                <h3 class="card-title"><b>{{$kosmetik->nama}}</b></h3>
                <h5 class="card-title">{{$kosmetik->kategori}}</h5>
                <p class="card-text"><b>Harga </b><i>{{$kosmetik->harga}}</i></p>
                <p class="card-text"><b>Stok </b><i>{{$kosmetik->stok}}</i></p>
                <a href="/kosmetik/index" class="card-link">Kembali</a>
             
                </div>
            </div>

        </div>
    </div>
</div>
@endsection 