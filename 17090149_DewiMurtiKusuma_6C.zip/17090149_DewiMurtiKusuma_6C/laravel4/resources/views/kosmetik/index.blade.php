@extends('layout/main')
@section('content')
@if (session('status'))
                <div class="alert alert-success">
                    {{session ('status')}}
                </div>
            @endif
<div class="container">
    <div class="row">
            <h1 class="mt-3">Daftar Product</h1>          
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Product</th>
                    <th scope="col">Kategori Product</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Stok</th>
                    <th scope="col">Opsi</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($kosmetik as $km)
                    <tr>
                        <th scope="row">{{ $loop->iteration}}</th>
                        <td>{{$km->nama}}</td>
                        <td>{{$km->kategori}}</td>
                        <td>{{$km->harga}}</td>
                        <td>{{$km->stok}}</td>
                        <td>
                        <a href="{{$km->id}}/edit" class="btn btn-success">Ubah</a>
                        <form action="/kosmetik/{{ $km->id }}" method="post" class="d-inline">
                        @method('delete')
                        @csrf
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Data Akan dihapus ?')">Hapus</button>
                        </form>
                        <a href="/kosmetik/{{$km->id}}" class="btn btn-info">Lihat</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection 