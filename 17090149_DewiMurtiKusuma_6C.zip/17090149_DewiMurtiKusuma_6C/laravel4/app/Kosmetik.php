<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kosmetik extends Model
{
    protected $table = 'kosmetik';

    protected $fillable = ['nama','kategori','harga','stok'];

}
