<?php

namespace App\Http\Controllers;

use App\Kosmetik;
use Illuminate\Http\Request;

class KosmetikController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kosmetik = Kosmetik::all();
        return view('kosmetik.index', compact('kosmetik'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('kosmetik.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'kategori' => 'required',
            'harga' => 'required',
            'stok' => 'required'

        ]);

        //menggunakn fillabel di model
        Kosmetik::create($request->all());
        return redirect('/kosmetik/index')->with('status', 'Data Berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Kosmetik  $kosmetik
     * @return \Illuminate\Http\Response
     */
    public function show(Kosmetik $kosmetik)
    {
        return view('kosmetik/lihat', compact('kosmetik'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Kosmetik  $kosmetik
     * @return \Illuminate\Http\Response
     */
    public function edit(Kosmetik $kosmetik)
    {
        return view('kosmetik/edit', compact('kosmetik'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Kosmetik  $kosmetik
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kosmetik $kosmetik)
    {
        $request->validate([
            'nama' => 'required',
            'kategori' => 'required',
            'harga' => 'required',
            'stok' => 'required'

        ]);
        Kosmetik::where('id',$kosmetik->id)
            ->update([
                'nama' => $request->nama,
                'kategori' => $request->kategori,
                'harga' => $request->harga,
                'stok' => $request->stok
            ]);
            return redirect('/kosmetik/index')->with('status', 'Data Berhasil diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Kosmetik  $kosmetik
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kosmetik $kosmetik)
    {
        Kosmetik::destroy($kosmetik->id);
        return redirect('/kosmetik/index')->with('status', 'Data Berhasil dihapus'); 
    }
}
