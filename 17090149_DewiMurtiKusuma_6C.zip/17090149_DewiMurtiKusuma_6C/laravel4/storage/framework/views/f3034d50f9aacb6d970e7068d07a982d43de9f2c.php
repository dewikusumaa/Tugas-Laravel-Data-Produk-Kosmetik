<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-4">
            <h1 class="mt-3">Detail Product</h1>

            <div class="card">
                <div class="card-body">
                <h3 class="card-title"><b><?php echo e($kosmetik->nama); ?></b></h3>
                <h5 class="card-title"><?php echo e($kosmetik->kategori); ?></h5>
                <p class="card-text"><b>Harga </b><i><?php echo e($kosmetik->harga); ?></i></p>
                <p class="card-text"><b>Stok </b><i><?php echo e($kosmetik->stok); ?></i></p>
                <a href="/kosmetik/index" class="card-link">Kembali</a>
             
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel4\resources\views/kosmetik/lihat.blade.php ENDPATH**/ ?>