<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 20px ">
<table class="table table-hover table-bordered">
<tbody>
    <?php $__currentLoopData = $pelanggann; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td>ID : <?php echo e($m['no']); ?></td>
    </tr>
    <tr><td>Nama : <?php echo e($m['nama']); ?></td></tr>
    <tr><td>Id : <?php echo e($m['id']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
    <a class="btn btn-danger" href="<?php echo e(route('pelanggan.index')); ?>">< Kembali</a>
    </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblaravel\resources\views/detail.blade.php ENDPATH**/ ?>