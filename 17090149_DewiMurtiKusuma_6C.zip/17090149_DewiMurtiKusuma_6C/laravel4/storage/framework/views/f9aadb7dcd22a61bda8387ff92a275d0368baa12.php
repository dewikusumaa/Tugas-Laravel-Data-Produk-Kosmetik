<?php $__env->startSection('content'); ?>
<div  style ="margin-top: 20px  " class="container">
<form action="<?php echo e(route('pelanggan.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group col-sm-4">
        <label>Nama Pelanggan</label>
        <input type="text" class="form-control" name="name">  
    </div>
    <div class="form-group col-sm-4">
        <label>Id Pelanggan</label>
        <input type="text" class="form-control" name="id"> 
    </div>
     
    <input class="btn btn-primary" type="submit" value="Tambahkan">
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblaravel\resources\views/create.blade.php ENDPATH**/ ?>