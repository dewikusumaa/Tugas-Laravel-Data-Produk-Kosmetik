<?php $__env->startSection('content'); ?>
<div class="container"style="margin-top: 20px "> 
    <?php $__currentLoopData = $materiall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="<?php echo e(route('material.update', $m['no'])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT">
        <input type="hidden"  name="old_name" value="<?php echo e($m['nama']); ?>">
        
        <div class="form-group col-sm-4">
        <label>Nama Material</label>
            <input type="text" class="form-control" name="name" value="<?php echo e($m['nama']); ?>">
        </div>
        
        <div class="form-group col-sm-4">
        <label>Kode Material</label>
          <input type="text" class="form-control" name="id" value="<?php echo e($m['id']); ?>">  
        </div>
        <div class="form-group col-sm-4">
        <input type="submit" value="Edit" class="btn btn-primary">
        </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\weblaravel\resources\views/edit.blade.php ENDPATH**/ ?>