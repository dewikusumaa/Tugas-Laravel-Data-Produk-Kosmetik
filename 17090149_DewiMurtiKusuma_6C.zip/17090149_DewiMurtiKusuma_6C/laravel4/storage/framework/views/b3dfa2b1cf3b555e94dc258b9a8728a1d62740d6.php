<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-4">
            <h1 class="mt-3">Detail Supplier</h1>

            <div class="card">
                <div class="card-body">
                <h4 class="card-title"><b><?php echo e($supplier->nama); ?></b></h5>
                <h6 class="card-subtitle mb-4 text-muted"><u><?php echo e($supplier->alamat); ?></u></h6>
                <p class="card-text"><b>Email </b><i><?php echo e($supplier->email); ?></i></p>
                <p class="card-text"><b>No HP </b><?php echo e($supplier->no_hp); ?></p>
                <p class="card-text"><b>Kategori Product </b><?php echo e($supplier->jenis); ?></p>
                <a href="/supplier/index" class="card-link">Kembali</a>
             
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel4\resources\views/supplier/lihat.blade.php ENDPATH**/ ?>