<?php $__env->startSection('content'); ?>


<div class="container">

    <div class="row">

         
            <h1 class="mt-3">Daftar Kategori Kosmetik</h1>
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Kode Kategori</th>
                    <th scope="col">Opsi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($ktgr->nama); ?></td>
                        <td><?php echo e($ktgr->kode); ?></td>
                        <td>
                        <a href="<?php echo e($ktgr->id); ?>/edit" class="btn btn-success">Ubah</a>
                        <form action="/kategoris/<?php echo e($ktgr->id); ?>" method="post" class="d-inline">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Data Akan dihapus ?')">Hapus</button>
                        </form>
            
                        <a href="/kategoris/<?php echo e($ktgr->id); ?>" class="btn btn-info">Lihat</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel4\resources\views/kategoris/index.blade.php ENDPATH**/ ?>