<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session ('status')); ?>

                </div>
            <?php endif; ?>
<div class="container">
    <div class="row">
            <h1 class="mt-3">Daftar Product</h1>          
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Product</th>
                    <th scope="col">Kategori Product</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Stok</th>
                    <th scope="col">Opsi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $kosmetik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $km): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($km->nama); ?></td>
                        <td><?php echo e($km->kategori); ?></td>
                        <td><?php echo e($km->harga); ?></td>
                        <td><?php echo e($km->stok); ?></td>
                        <td>
                        <a href="<?php echo e($km->id); ?>/edit" class="btn btn-success">Ubah</a>
                        <form action="/kosmetik/<?php echo e($km->id); ?>" method="post" class="d-inline">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Data Akan dihapus ?')">Hapus</button>
                        </form>
                        <a href="/kosmetik/<?php echo e($km->id); ?>" class="btn btn-info">Lihat</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel4\resources\views/kosmetik/index.blade.php ENDPATH**/ ?>