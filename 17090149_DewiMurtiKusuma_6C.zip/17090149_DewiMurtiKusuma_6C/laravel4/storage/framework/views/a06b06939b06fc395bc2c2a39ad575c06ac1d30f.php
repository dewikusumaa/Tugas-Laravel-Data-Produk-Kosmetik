<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session ('status')); ?>

                </div>
            <?php endif; ?>
<div class="container">
    <div class="row">
            <h1 class="mt-3">Daftar Pegawai</h1>          
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Pelanggan</th>
                    <th scope="col">Jabatan</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Email</th>
                    <th scope="col">No Handphone</th>
                    <th scope="col">Opi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($peg->nama); ?></td>
                        <td><?php echo e($peg->jabatan); ?></td>
                        <td><?php echo e($peg->alamat); ?></td>
                        <td><?php echo e($peg->email); ?></td>
                        <td><?php echo e($peg->no_hp); ?></td>
                        <td>
                        <a href="<?php echo e($peg->id); ?>/edit" class="btn btn-success">Ubah</a>
                        <form action="/pelanggan/<?php echo e($peg->id); ?>" method="post" class="d-inline">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Data Akan dihapus ?')">Hapus</button>
                        </form>
                        <a href="/pegawai/<?php echo e($peg->id); ?>" class="btn btn-info">Lihat</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblaravel\resources\views/pegawai/index.blade.php ENDPATH**/ ?>