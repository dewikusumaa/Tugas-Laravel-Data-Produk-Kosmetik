<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
    <h1 style="color: green"><?php echo e($message); ?></h1>
    <?php elseif($message = Session::get('error')): ?>
    <h1 style="color: red"><?php echo e($message); ?></h1>
    <?php endif; ?>
    <div class="container">
        <div style="margin-top: 20px ">
            <div class="row">
                <div class="col-md-4">
                    <a class="btn btn-warning" href="<?php echo e(route('pelanggan.create')); ?>">Tambah Data Pelanggan</a><br><br>
                    <div class="container">
                    <div class="col-mt-2">
                    <form action="" method="get">
                    <select name="class">
                        <option value="">Semua</option>
                        <option value="011">011</option>
                        <option value="022">022</option>
                        <option value="033">033</option>
                        <option value="044">044</option>
                    </select>
                    </div>
                    </div><br>
                    <input type="submit" value="Cari">
                    </form><br><br>

                </div>
            </div>
        </div>

                    <div class="body">
                        <table class="table table-striped">
                            <thead class="thead-dark">
                                <tr>
                                    <th><b>No.</b></th>
                                    <th><b>id pelanggan</b></th>
                                    <th><b>Nama</b></th>
                                    <th><b>Action</b></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($m['no']); ?></td>
                                        <td><?php echo e($m['id']); ?></td>
                                        <td><?php echo e($m['nama']); ?></td>
                                        <td><a class="btn btn-success" href="<?php echo e(route('pelanggan.show', $m['no'])); ?>">Lihat</a> || <a class="btn btn-warning" href="<?php echo e(route('pelanggan.edit',$m['no'])); ?>">Edit</a> <br><br>
                                        <form action="<?php echo e(route('pelanggan.destroy', $m['no'])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" value="<?php echo e($m['nama']); ?>" name="name">
                                            <input class="btn btn-danger"type="submit" value="Hapus" onclick="return alert('Apakah anda yakin?')">
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        </div>
                        <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblaravel\resources\views/pelanggan.blade.php ENDPATH**/ ?>